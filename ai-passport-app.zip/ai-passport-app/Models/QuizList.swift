import Foundation

struct QuizList: Decodable {
    let questions: [Quiz]
}
