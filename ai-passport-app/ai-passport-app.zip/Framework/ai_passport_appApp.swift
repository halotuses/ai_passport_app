import SwiftUI

/// アプリ起動エントリーポイント
@main
struct ai_passport_appApp: App {
    var body: some Scene {
        WindowGroup {
            AppFrameView()
        }
    }
}
