import Foundation

struct ChapterList: Decodable {
    let chapters: [ChapterMetadata]
}
